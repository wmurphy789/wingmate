class DashboardController < ApplicationController

  def index
    
  end

  def privacy_policy
  end


end
