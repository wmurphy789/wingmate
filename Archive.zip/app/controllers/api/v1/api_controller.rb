class Api::V1::ApiController < Api::ApiController

end
