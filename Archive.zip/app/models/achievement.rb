class Achievement < ActiveRecord::Base
	belongs_to :achievment_type
end
