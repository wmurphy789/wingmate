class AchievmentType < ActiveRecord::Base
	has_many :achievement
end
