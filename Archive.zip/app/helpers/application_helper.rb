module ApplicationHelper
	def app_name
		'Wingmate'
	end
end
